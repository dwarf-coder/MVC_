public class InternView {
    public void printInternDetails(String internName, String internLastname){
       System.out.println("Intern: ");
       System.out.println("Name: " + internName);
       System.out.println("Lastname: " + internLastname);
    }
 }